using GameEngine.Play;
using GameEngineHost.Services;
using Microsoft.AspNetCore.Mvc;

namespace GameEngineHost.Controllers;

[ApiController]
[Route("play")]
public sealed class PlayController : ControllerBase
{
    private readonly IEngineClient _engineClient;

    public PlayController(IEngineClient engineClient)
    {
        _engineClient = engineClient;
    }

    [HttpPost]
    public async Task<ActionResult<PlayResponse>> Play([FromBody] PlayRequest request, CancellationToken cancellationToken)
    {
        var response = await _engineClient.PlayAsync(request, cancellationToken);
        return Ok(response);
    }
}

