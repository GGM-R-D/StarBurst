using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using GameEngine.Configuration;
using GameEngine.Services;
using RNGClient;

namespace GameEngine.Play;

public sealed class SpinHandler
{
    private readonly GameConfigurationLoader _configurationLoader;
    private readonly WinEvaluator _winEvaluator;
    private readonly IRngClient _rngClient;
    private readonly ITimeService _timeService;
    private readonly FortunaPrng _fortunaPrng;
    private readonly ISpinTelemetrySink _telemetry;

    public SpinHandler(
        GameConfigurationLoader configurationLoader,
        WinEvaluator winEvaluator,
        ITimeService timeService,
        FortunaPrng fortunaPrng,
        IRngClient rngClient,
        ISpinTelemetrySink telemetry)
    {
        _configurationLoader = configurationLoader;
        _winEvaluator = winEvaluator;
        _timeService = timeService;
        _fortunaPrng = fortunaPrng;
        _rngClient = rngClient;
        _telemetry = telemetry;
    }

    public async Task<PlayResponse> PlayAsync(PlayRequest request, CancellationToken cancellationToken = default)
    {
        ValidateRequest(request);

        var configuration = await _configurationLoader.GetConfigurationAsync(request.GameId, cancellationToken);
        var roundId = CreateRoundId();
        var nextState = request.EngineState?.Clone() ?? EngineSessionState.Create();
        var spinMode = request.IsFeatureBuy
            ? SpinMode.BuyEntry
            : nextState.IsInFreeSpins ? SpinMode.FreeSpins : SpinMode.BaseGame;

        var buyCost = request.IsFeatureBuy
            ? Money.FromBet(request.BaseBet.Amount, configuration.BuyFeature.CostMultiplier)
            : Money.Zero;

        var reelStrips = SelectReelStrips(configuration, spinMode, request.BetMode);
        var randomContext = await FetchRandomContext(configuration, reelStrips, request, roundId, spinMode, cancellationToken);
        var multiplierFactory = new Func<SymbolDefinition, decimal>(symbol =>
            AssignMultiplierValue(symbol, configuration, request.BetMode, spinMode, nextState.FreeSpins, randomContext));

        var board = ReelBoard.Create(
            reelStrips,
            configuration.SymbolMap,
            configuration.Board.Rows,
            multiplierFactory,
            randomContext.ReelStartSeeds,
            _fortunaPrng);

        var cascades = new List<CascadeStep>();
        var wins = new List<SymbolWin>();
        var cascadeIndex = 0;
        Money totalWin = Money.Zero;
        Money scatterWin = Money.Zero;
        Money featureWin = nextState.FreeSpins?.FeatureWin ?? Money.Zero;
        int freeSpinsAwarded = 0;

        while (true)
        {
            var gridSnapshot = board.FlattenCodes();
            var evaluation = _winEvaluator.Evaluate(gridSnapshot, configuration, request.TotalBet);

            if (evaluation.SymbolWins.Count == 0)
            {
                break;
            }

            wins.AddRange(evaluation.SymbolWins);
            var cascadeBaseWin = evaluation.TotalWin;
            var cascadeFinalWin = cascadeBaseWin;
            decimal appliedMultiplier = 1m;

            var multiplierSum = board.SumMultipliers();
            if (spinMode == SpinMode.BaseGame || spinMode == SpinMode.BuyEntry)
            {
                if (multiplierSum > 0m && cascadeBaseWin.Amount > 0)
                {
                    appliedMultiplier = multiplierSum;
                    cascadeFinalWin = cascadeBaseWin * multiplierSum;
                }
            }
            else if (nextState.FreeSpins is not null)
            {
                if (multiplierSum > 0m)
                {
                    nextState.FreeSpins.TotalMultiplier += multiplierSum;
                }

                if (nextState.FreeSpins.TotalMultiplier > 0m && cascadeBaseWin.Amount > 0)
                {
                    appliedMultiplier = nextState.FreeSpins.TotalMultiplier;
                    cascadeFinalWin = cascadeBaseWin * nextState.FreeSpins.TotalMultiplier;
                }
            }

            totalWin += cascadeFinalWin;

            if (spinMode == SpinMode.FreeSpins && nextState.FreeSpins is not null)
            {
                featureWin += cascadeFinalWin;
                nextState.FreeSpins.FeatureWin = featureWin;
            }

            cascades.Add(new CascadeStep(
                Index: cascadeIndex++,
                GridSymbols: gridSnapshot,
                WinsAfterCascade: evaluation.SymbolWins,
                BaseWin: cascadeBaseWin,
                AppliedMultiplier: appliedMultiplier,
                TotalWin: cascadeFinalWin));

            var winningCodes = evaluation.SymbolWins
                .Select(win => win.SymbolCode)
                .ToHashSet(StringComparer.Ordinal);

            board.RemoveSymbols(winningCodes);
            board.RemoveMultipliers();

            if (!board.NeedsRefill)
            {
                continue;
            }

            board.Refill();
        }

        var scatterOutcome = ResolveScatterOutcome(board, configuration, request.TotalBet);
        if (scatterOutcome is not null)
        {
            scatterWin = scatterOutcome.Win;
            totalWin += scatterWin;

            if ((spinMode == SpinMode.BaseGame || spinMode == SpinMode.BuyEntry) && scatterOutcome.FreeSpinsAwarded > 0)
            {
                InitializeFreeSpins(configuration, nextState);
                spinMode = SpinMode.FreeSpins;
                freeSpinsAwarded = scatterOutcome.FreeSpinsAwarded;
            }
            else if (spinMode == SpinMode.FreeSpins && nextState.FreeSpins is not null)
            {
                if (scatterOutcome.SymbolCount >= configuration.FreeSpins.RetriggerScatterCount)
                {
                    nextState.FreeSpins.SpinsRemaining += configuration.FreeSpins.RetriggerSpins;
                    nextState.FreeSpins.TotalSpinsAwarded += configuration.FreeSpins.RetriggerSpins;
                    freeSpinsAwarded = configuration.FreeSpins.RetriggerSpins;
                }
            }
        }

        if (spinMode == SpinMode.FreeSpins && nextState.FreeSpins is not null)
        {
            nextState.FreeSpins.SpinsRemaining = Math.Max(0, nextState.FreeSpins.SpinsRemaining - 1);
            nextState.FreeSpins.JustTriggered = false;

            if (nextState.FreeSpins.SpinsRemaining == 0)
            {
                nextState.FreeSpins = null;
            }
        }

        var maxWin = Money.FromBet(request.TotalBet.Amount, configuration.MaxWinMultiplier);
        if (totalWin.Amount > maxWin.Amount)
        {
            totalWin = maxWin;
        }

        var featureSummary = nextState.FreeSpins is null
            ? null
            : new FeatureSummary(
                SpinsRemaining: nextState.FreeSpins.SpinsRemaining,
                TotalMultiplier: nextState.FreeSpins.TotalMultiplier,
                FeatureWin: nextState.FreeSpins.FeatureWin,
                TriggeredThisSpin: nextState.FreeSpins.JustTriggered);

        var response = new PlayResponse(
            StatusCode: 200,
            Win: totalWin,
            ScatterWin: scatterWin,
            FeatureWin: featureSummary?.FeatureWin ?? Money.Zero,
            BuyCost: buyCost,
            FreeSpinsAwarded: freeSpinsAwarded,
            RoundId: roundId,
            Timestamp: _timeService.UtcNow,
            NextState: nextState,
            Results: new ResultsEnvelope(
                Cascades: cascades,
                Wins: wins,
                Scatter: scatterOutcome,
                FreeSpins: featureSummary,
                RngTransactionId: roundId));

        _telemetry.Record(new SpinTelemetryEvent(
            GameId: request.GameId,
            BetMode: request.BetMode,
            SpinMode: spinMode,
            TotalBet: request.TotalBet.Amount + buyCost.Amount,
            TotalWin: totalWin.Amount,
            ScatterWin: scatterWin.Amount,
            FeatureWin: featureSummary?.FeatureWin.Amount ?? 0m,
            BuyCost: buyCost.Amount,
            Cascades: cascades.Count,
            TriggeredFreeSpins: freeSpinsAwarded > 0,
            FreeSpinMultiplier: nextState.FreeSpins?.TotalMultiplier ?? 0m,
            Timestamp: response.Timestamp));

        return response;
    }

    private static void ValidateRequest(PlayRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.GameId))
        {
            throw new ArgumentException("gameId is required.", nameof(request.GameId));
        }

        if (request.Bets is null || request.Bets.Count == 0)
        {
            throw new ArgumentException("At least one bet entry is required.", nameof(request.Bets));
        }

        if (request.EngineState is null)
        {
            throw new ArgumentException("Engine state is required.", nameof(request.EngineState));
        }

        if (request.TotalBet.Amount <= 0)
        {
            throw new ArgumentException("Total bet must be positive.", nameof(request.TotalBet));
        }
    }

    private IReadOnlyList<IReadOnlyList<string>> SelectReelStrips(
        GameConfiguration configuration,
        SpinMode mode,
        BetMode betMode)
    {
        return mode switch
        {
            SpinMode.FreeSpins => configuration.ReelLibrary.FreeSpins,
            SpinMode.BuyEntry => configuration.ReelLibrary.Buy,
            _ => SelectBaseReels(configuration, betMode)
        };
    }

    private IReadOnlyList<IReadOnlyList<string>> SelectBaseReels(GameConfiguration configuration, BetMode betMode)
    {
        var key = betMode == BetMode.Ante ? "ante" : "standard";
        if (!configuration.BetModes.TryGetValue(key, out var modeDefinition))
        {
            return configuration.ReelLibrary.High;
        }

        var lowWeight = Math.Max(0, modeDefinition.ReelWeights.Low);
        var highWeight = Math.Max(0, modeDefinition.ReelWeights.High);
        var total = lowWeight + highWeight;
        if (total <= 0)
        {
            return configuration.ReelLibrary.High;
        }

        var roll = _fortunaPrng.NextInt32(0, total);
        return roll < lowWeight ? configuration.ReelLibrary.Low : configuration.ReelLibrary.High;
    }

    private async Task<RandomContext> FetchRandomContext(
        GameConfiguration configuration,
        IReadOnlyList<IReadOnlyList<string>> reelStrips,
        PlayRequest request,
        string roundId,
        SpinMode spinMode,
        CancellationToken cancellationToken)
    {
        try
        {
            var pools = new List<PoolRequest>
            {
                new(
                    PoolId: "reel-starts",
                    DrawCount: reelStrips.Count,
                    Metadata: new Dictionary<string, object>
                    {
                        ["reelLengths"] = reelStrips.Select(strip => strip.Count).ToArray()
                    }),
                new(
                    PoolId: "multiplier-seeds",
                    DrawCount: configuration.Board.Columns * configuration.Board.Rows,
                    Metadata: new Dictionary<string, object>
                    {
                        ["multiplierValues"] = configuration.Multiplier.Values
                    })
            };

            var rngRequest = new JurisdictionPoolsRequest
            {
                GameId = request.GameId,
                RoundId = roundId,
                Pools = pools,
                TrackingData = new Dictionary<string, string>
                {
                    ["playerToken"] = request.PlayerToken,
                    ["mode"] = spinMode.ToString(),
                    ["betMode"] = request.BetMode.ToString()
                }
            };

            var response = await _rngClient.RequestPoolsAsync(rngRequest, cancellationToken).ConfigureAwait(false);
            var reelStartSeeds = ExtractIntegers(response, "reel-starts", reelStrips.Count);
            var multiplierSeeds = ExtractIntegers(response, "multiplier-seeds", configuration.Board.Columns * configuration.Board.Rows);

            return RandomContext.FromSeeds(reelStartSeeds, multiplierSeeds);
        }
        catch
        {
            return RandomContext.CreateFallback(reelStrips.Count, configuration.Board.Columns * configuration.Board.Rows, _fortunaPrng);
        }
    }

    private static IReadOnlyList<int> ExtractIntegers(PoolsResponse response, string poolId, int expectedCount)
    {
        var pool = response.Pools.FirstOrDefault(p => string.Equals(p.PoolId, poolId, StringComparison.OrdinalIgnoreCase));
        if (pool == null)
        {
            return Enumerable.Repeat(0, expectedCount).ToArray();
        }

        var results = new List<int>(expectedCount);
        foreach (var result in pool.Results.Take(expectedCount))
        {
            if (int.TryParse(result, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
            {
                results.Add(value);
            }
        }

        while (results.Count < expectedCount)
        {
            results.Add(results.Count);
        }

        return results;
    }

    private decimal AssignMultiplierValue(
        SymbolDefinition definition,
        GameConfiguration configuration,
        BetMode betMode,
        SpinMode spinMode,
        FreeSpinState? freeSpinState,
        RandomContext randomContext)
    {
        if (definition.Type != SymbolType.Multiplier)
        {
            return 0m;
        }

        IReadOnlyList<MultiplierWeight> profile = configuration.MultiplierProfiles.Standard;

        if (spinMode == SpinMode.FreeSpins && freeSpinState is not null)
        {
            profile = freeSpinState.TotalMultiplier >= configuration.MultiplierProfiles.FreeSpinsSwitchThreshold
                ? configuration.MultiplierProfiles.FreeSpinsLow
                : configuration.MultiplierProfiles.FreeSpinsHigh;
        }
        else if (betMode == BetMode.Ante)
        {
            profile = configuration.MultiplierProfiles.Ante;
        }

        var seed = randomContext.TryDequeueMultiplierSeed(out var rngSeed)
            ? rngSeed
            : _fortunaPrng.NextInt32(0, int.MaxValue);

        return RollMultiplier(profile, seed);
    }

    private decimal RollMultiplier(IReadOnlyList<MultiplierWeight> weights, int seed)
    {
        var total = weights.Sum(w => Math.Max(0, w.Weight));
        if (total <= 0)
        {
            return weights.Count > 0 ? weights[^1].Value : 0m;
        }

        var roll = Math.Abs(seed) % total;
        var cumulative = 0;
        foreach (var weight in weights)
        {
            cumulative += Math.Max(0, weight.Weight);
            if (roll < cumulative)
            {
                return weight.Value;
            }
        }

        return weights[^1].Value;
    }

    private static ScatterOutcome? ResolveScatterOutcome(ReelBoard board, GameConfiguration configuration, Money bet)
    {
        var scatterCount = board.CountSymbols(symbol => symbol.Type == SymbolType.Scatter);
        if (scatterCount == 0)
        {
            return null;
        }

        var reward = configuration.Scatter.Rewards
            .Where(r => scatterCount >= r.Count)
            .OrderByDescending(r => r.Count)
            .FirstOrDefault();

        if (reward is null)
        {
            return null;
        }

        var win = Money.FromBet(bet.Amount, reward.PayoutMultiplier);
        return new ScatterOutcome(scatterCount, win, reward.FreeSpinsAwarded);
    }

    private static void InitializeFreeSpins(GameConfiguration configuration, EngineSessionState state)
    {
        state.FreeSpins = new FreeSpinState
        {
            SpinsRemaining = configuration.FreeSpins.InitialSpins,
            TotalSpinsAwarded = configuration.FreeSpins.InitialSpins,
            TotalMultiplier = 0,
            FeatureWin = Money.Zero,
            JustTriggered = true
        };
    }

    private string CreateRoundId()
    {
        var randomSuffix = _fortunaPrng.NextInt32(0, int.MaxValue);
        return $"{_timeService.UnixMilliseconds:X}-{randomSuffix:X}";
    }

    private sealed class ReelBoard
    {
        private readonly List<ReelColumn> _columns;
        private readonly int _rows;

        private ReelBoard(List<ReelColumn> columns, int rows)
        {
            _columns = columns;
            _rows = rows;
        }

        public static ReelBoard Create(
            IReadOnlyList<IReadOnlyList<string>> reelStrips,
            IReadOnlyDictionary<string, SymbolDefinition> symbolMap,
            int rows,
            Func<SymbolDefinition, decimal> multiplierFactory,
            IReadOnlyList<int> reelStartSeeds,
            FortunaPrng prng)
        {
            if (reelStrips.Count == 0)
            {
                throw new InvalidOperationException("Reel strips are not configured.");
            }

            var columns = new List<ReelColumn>(reelStrips.Count);
            for (var columnIndex = 0; columnIndex < reelStrips.Count; columnIndex++)
            {
                var strip = reelStrips[columnIndex];
                if (strip.Count == 0)
                {
                    throw new InvalidOperationException($"Reel {columnIndex} is empty.");
                }

                var startIndex = reelStartSeeds is not null && columnIndex < reelStartSeeds.Count
                    ? Math.Abs(reelStartSeeds[columnIndex]) % strip.Count
                    : prng.NextInt32(0, strip.Count);
                columns.Add(new ReelColumn(strip, startIndex, rows, symbolMap, multiplierFactory));
            }

            return new ReelBoard(columns, rows);
        }

        public bool NeedsRefill => _columns.Any(column => column.Count < _rows);

        public void Refill()
        {
            foreach (var column in _columns)
            {
                column.Refill(_rows);
            }
        }

        public List<string> FlattenCodes()
        {
            var snapshot = new List<string>(_columns.Count * _rows);

            for (var row = _rows - 1; row >= 0; row--)
            {
                foreach (var column in _columns)
                {
                    snapshot.Add(row < column.Count ? column[row].Definition.Code : string.Empty);
                }
            }

            return snapshot;
        }

        public decimal SumMultipliers() =>
            _columns.SelectMany(column => column.Symbols)
                .Where(instance => instance.Definition.Type == SymbolType.Multiplier)
                .Sum(instance => instance.MultiplierValue);

        public int CountSymbols(Func<SymbolDefinition, bool> predicate) =>
            _columns.SelectMany(column => column.Symbols)
                .Count(instance => predicate(instance.Definition));

        public void RemoveSymbols(ISet<string> targets)
        {
            foreach (var column in _columns)
            {
                column.RemoveWhere(symbol => targets.Contains(symbol.Definition.Code));
            }
        }

        public void RemoveMultipliers()
        {
            foreach (var column in _columns)
            {
                column.RemoveWhere(symbol => symbol.Definition.Type == SymbolType.Multiplier);
            }
        }
    }

    private sealed class ReelColumn
    {
        private readonly IReadOnlyList<string> _strip;
        private readonly IReadOnlyDictionary<string, SymbolDefinition> _symbolMap;
        private readonly Func<SymbolDefinition, decimal> _multiplierFactory;
        private int _nextIndex;

        public List<SymbolInstance> Symbols { get; }

        public ReelColumn(
            IReadOnlyList<string> strip,
            int startIndex,
            int rows,
            IReadOnlyDictionary<string, SymbolDefinition> symbolMap,
            Func<SymbolDefinition, decimal> multiplierFactory)
        {
            _strip = strip;
            _symbolMap = symbolMap;
            _multiplierFactory = multiplierFactory;
            _nextIndex = startIndex;
            Symbols = new List<SymbolInstance>(rows);

            for (var i = 0; i < rows; i++)
            {
                Symbols.Add(CreateInstance());
            }
        }

        public int Count => Symbols.Count;

        public SymbolInstance this[int index] => Symbols[index];

        public void Refill(int desiredRows)
        {
            while (Symbols.Count < desiredRows)
            {
                Symbols.Add(CreateInstance());
            }
        }

        public void RemoveWhere(Func<SymbolInstance, bool> predicate) =>
            Symbols.RemoveAll(instance => predicate(instance));

        private SymbolInstance CreateInstance()
        {
            var definition = ResolveSymbol(_strip[_nextIndex]);
            _nextIndex = (_nextIndex + 1) % _strip.Count;
            var multiplier = _multiplierFactory(definition);
            return new SymbolInstance(definition, multiplier);
        }

        private SymbolDefinition ResolveSymbol(string symCode)
        {
            if (!_symbolMap.TryGetValue(symCode, out var definition))
            {
                throw new InvalidOperationException($"Unknown symbol `{symCode}` on reel.");
            }

            return definition;
        }
    }

    private sealed record SymbolInstance(SymbolDefinition Definition, decimal MultiplierValue);

    private sealed class RandomContext
    {
        private readonly IReadOnlyList<int> _reelSeeds;
        private readonly Queue<int> _multiplierSeeds;

        private RandomContext(IReadOnlyList<int> reelSeeds, Queue<int> multiplierSeeds)
        {
            _reelSeeds = reelSeeds;
            _multiplierSeeds = multiplierSeeds;
        }

        public IReadOnlyList<int> ReelStartSeeds => _reelSeeds;

        public bool TryDequeueMultiplierSeed(out int seed)
        {
            if (_multiplierSeeds.Count > 0)
            {
                seed = _multiplierSeeds.Dequeue();
                return true;
            }

            seed = 0;
            return false;
        }

        public static RandomContext FromSeeds(IReadOnlyList<int> reelSeeds, IReadOnlyList<int> multiplierSeeds) =>
            new(reelSeeds, new Queue<int>(multiplierSeeds));

        public static RandomContext CreateFallback(int reelCount, int multiplierSeedCount, FortunaPrng prng)
        {
            var reelSeeds = Enumerable.Range(0, reelCount)
                .Select(_ => prng.NextInt32(0, int.MaxValue))
                .ToArray();
            var multiplierSeeds = Enumerable.Range(0, multiplierSeedCount)
                .Select(_ => prng.NextInt32(0, int.MaxValue))
                .ToArray();
            return FromSeeds(reelSeeds, multiplierSeeds);
        }
    }
}

