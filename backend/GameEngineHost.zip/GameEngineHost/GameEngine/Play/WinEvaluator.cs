using System.Collections.Generic;
using System.Linq;
using GameEngine.Configuration;

namespace GameEngine.Play;

public sealed class WinEvaluator
{
    public WinEvaluationResult Evaluate(IReadOnlyList<string> grid, GameConfiguration configuration, Money bet)
    {
        var wins = new List<SymbolWin>();
        var totalWin = 0m;

        foreach (var entry in configuration.Paytable)
        {
            var symbolCount = grid.Count(symbol => symbol == entry.SymbolCode);
            if (symbolCount < 8)
            {
                continue;
            }

            var bestMatch = entry.Multipliers
                .Where(mult => symbolCount >= mult.Count)
                .OrderByDescending(mult => mult.Count)
                .FirstOrDefault();

            if (bestMatch is null)
            {
                continue;
            }

            var payout = Money.FromBet(bet.Amount, bestMatch.Multiplier);
            wins.Add(new SymbolWin(entry.SymbolCode, symbolCount, bestMatch.Multiplier, payout));
            totalWin += payout.Amount;
        }

        return new WinEvaluationResult(new Money(totalWin), wins);
    }
}

public sealed record WinEvaluationResult(Money TotalWin, IReadOnlyList<SymbolWin> SymbolWins);

