export const gameConfig = {
  reels: 5,
  rows: 3,
  paylines: 10,
  title: 'Stellar Gems'
};

