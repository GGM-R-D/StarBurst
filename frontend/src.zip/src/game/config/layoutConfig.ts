export { REEL_COLS, REEL_ROWS, type ReelLayout, computeReelLayout } from './ReelLayout';

