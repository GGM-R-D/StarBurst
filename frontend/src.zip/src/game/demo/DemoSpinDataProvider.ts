import { REEL_COLS, REEL_ROWS } from '@game/config/layoutConfig';
import type { SpinResult, SymbolId } from './SpinTypes';
import { ISpinDataProvider } from './ISpinDataProvider';

// Base symbols used for normal spins (wild injected separately).
// SYM_WILD can appear only on reels 2,3,4 (indices 1,2,3)
// Highest to lowest: Bar, Seven, Orange, Green, Red, Blue, Purple.
const BASE_SYMBOLS: SymbolId[] = [
  'SYM_BAR',
  'SYM_SEVEN',
  'SYM_ORANGE',
  'SYM_GREEN',
  'SYM_RED',
  'SYM_BLUE',
  'SYM_PURPLE'
];

export class DemoSpinDataProvider implements ISpinDataProvider {
  getNextSpin(): SpinResult {
    const symbols: SymbolId[][] = [];

    for (let c = 0; c < REEL_COLS; c++) {
      const column: SymbolId[] = [];
      for (let r = 0; r < REEL_ROWS; r++) {
        // Only allow wilds on center reels 2,3,4 (indices 1,2,3)
        // Reels 1 and 5 (indices 0 and 4) must NEVER have any wild symbols
        if (c === 1 || c === 2 || c === 3) {
          // Small chance (5%) to generate a wild in this position.
          if (Math.random() < 0.05) {
            column.push('SYM_WILD');
            continue;
          }
        }

        // Use base symbols (no wilds can appear on reels 1 or 5)
        const id = BASE_SYMBOLS[Math.floor(Math.random() * BASE_SYMBOLS.length)];
        column.push(id);
      }
      symbols.push(column);
    }

    return { symbols };
  }

  /**
   * Generate a spin result with forced wild symbols on reels 2, 3, and 4 (columns 1, 2, 3).
   * Wilds will appear on the middle row (row index 1) of each reel.
   */
  getForcedWildSpin(): SpinResult {
    const symbols: SymbolId[][] = [];

    for (let c = 0; c < REEL_COLS; c++) {
      const column: SymbolId[] = [];
      for (let r = 0; r < REEL_ROWS; r++) {
        // Force wild symbols on reels 2, 3, 4 (indices 1, 2, 3) on the middle row (index 1)
        if ((c === 1 || c === 2 || c === 3) && r === 1) {
          column.push('SYM_WILD');
        } else {
          // Use random base symbols for all other positions
          const id = BASE_SYMBOLS[Math.floor(Math.random() * BASE_SYMBOLS.length)];
          column.push(id);
        }
      }
      symbols.push(column);
    }

    return { symbols };
  }
}


