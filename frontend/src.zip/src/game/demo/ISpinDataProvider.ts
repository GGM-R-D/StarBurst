import type { SpinResult } from './SpinTypes';

export interface ISpinDataProvider {
  getNextSpin(): SpinResult;
}


