import type { SymbolId } from '@game/demo/SpinTypes';
import { PAYLINES } from '@game/config/paylines';
import { getPayoutMultiplier } from '@game/config/symbolConfig';

export interface Win {
  lineId: number;
  paylineIndex: number;
  symbol: SymbolId;
  count: number;
  payout: number;
  positions: Array<{ reel: number; row: number }>;
}

/**
 * Helper function to evaluate a win in a specific direction
 * @param symbols - Array of symbols along the payline
 * @param positions - Array of positions along the payline
 * @param fromLeft - If true, check left-to-right; if false, check right-to-left
 * @returns Win info or null if no win
 */
function evaluateDirection(
  symbols: SymbolId[],
  positions: Array<{ reel: number; row: number }>,
  fromLeft: boolean
): { baseSymbol: SymbolId; matchCount: number; winPositions: Array<{ reel: number; row: number }> } | null {
  if (symbols.length < 3) return null;

  // Determine base symbol based on direction
  let baseSymbol: SymbolId | null = null;
  
  if (fromLeft) {
    // Find the first non-wild symbol from left
    for (const sym of symbols) {
      if (sym !== 'SYM_WILD') {
        baseSymbol = sym;
        break;
      }
    }
  } else {
    // Find the first non-wild symbol from right
    for (let i = symbols.length - 1; i >= 0; i--) {
      const sym = symbols[i];
      if (sym !== 'SYM_WILD') {
        baseSymbol = sym;
        break;
      }
    }
  }
  
  if (!baseSymbol) {
    // All wilds - wilds don't pay directly, return null
    return null;
  }

  // Count matching symbols in the specified direction
  let matchCount = 0;
  const winPositions: Array<{ reel: number; row: number }> = [];
  
  if (fromLeft) {
    // Check from left to right
    for (let i = 0; i < symbols.length; i++) {
      const sym = symbols[i];
      if (sym === baseSymbol || sym === 'SYM_WILD') {
        matchCount++;
        winPositions.push(positions[i]);
      } else {
        break; // Stop at first non-matching symbol
      }
    }
  } else {
    // Check from right to left
    for (let i = symbols.length - 1; i >= 0; i--) {
      const sym = symbols[i];
      if (sym === baseSymbol || sym === 'SYM_WILD') {
        matchCount++;
        winPositions.unshift(positions[i]); // Add to front to maintain left-to-right order
      } else {
        break; // Stop at first non-matching symbol
      }
    }
  }

  if (matchCount >= 3) {
    return { baseSymbol, matchCount, winPositions };
  }

  return null;
}

/**
 * Evaluates wins on the grid using paylines.
 * Checks both left-to-right and right-to-left directions.
 * @param grid - Column-major grid [col][row]
 * @param betPerLine - Bet amount per payline
 * @returns Array of win objects
 */
export function evaluateWins(grid: SymbolId[][], betPerLine: number): Win[] {
  const wins: Win[] = [];

  for (let paylineIndex = 0; paylineIndex < PAYLINES.length; paylineIndex++) {
    const payline = PAYLINES[paylineIndex];
    if (!payline || !payline.rows || payline.rows.length === 0) continue;

    // Convert rows array to positions: rows[i] is the row index for reel i
    const symbols: SymbolId[] = [];
    const positions: Array<{ reel: number; row: number }> = [];

    for (let reel = 0; reel < payline.rows.length && reel < grid.length; reel++) {
      const row = payline.rows[reel];
      const column = grid[reel];
      if (!column || row >= column.length || row < 0) break;

      symbols.push(column[row]);
      positions.push({ reel, row });
    }

    if (symbols.length < 3) continue; // Need at least 3 matching symbols

    // Check both directions
    const leftToRight = evaluateDirection(symbols, positions, true);
    const rightToLeft = evaluateDirection(symbols, positions, false);

    // Determine the best win (prefer higher count, then higher payout)
    let bestWin: { baseSymbol: SymbolId; matchCount: number; winPositions: Array<{ reel: number; row: number }> } | null = null;

    if (leftToRight && rightToLeft) {
      // Both directions have wins - choose the better one
      if (leftToRight.matchCount > rightToLeft.matchCount) {
        bestWin = leftToRight;
      } else if (rightToLeft.matchCount > leftToRight.matchCount) {
        bestWin = rightToLeft;
      } else {
        // Same count - check payout
        const leftMultiplier = getPayoutMultiplier(leftToRight.baseSymbol, leftToRight.matchCount);
        const rightMultiplier = getPayoutMultiplier(rightToLeft.baseSymbol, rightToLeft.matchCount);
        bestWin = leftMultiplier >= rightMultiplier ? leftToRight : rightToLeft;
      }
    } else if (leftToRight) {
      bestWin = leftToRight;
    } else if (rightToLeft) {
      bestWin = rightToLeft;
    }

    // Add the win if we found one
    if (bestWin) {
      const multiplier = getPayoutMultiplier(bestWin.baseSymbol, bestWin.matchCount);
      if (multiplier > 0) {
        const payout = betPerLine * multiplier;
        wins.push({
          lineId: payline.id,
          paylineIndex,
          symbol: bestWin.baseSymbol,
          count: bestWin.matchCount,
          payout,
          positions: bestWin.winPositions
        });
      }
    }
  }

  return wins;
}
