export type ReelStrip = number[];

export interface ReelStripSet {
  [reelIndex: number]: ReelStrip;
}

