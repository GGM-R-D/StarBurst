export class TransitionManager {
  playIntro(): void {
    console.info('Playing intro transition');
  }

  playBigWin(): void {
    console.info('Playing big win transition');
  }
}

