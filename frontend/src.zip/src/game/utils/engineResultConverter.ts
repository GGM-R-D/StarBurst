import type { SymbolId } from '@game/demo/SpinTypes';
import type { PlayResponse } from '@network/types';

/**
 * Converts game engine results to frontend format.
 * The engine returns FinalGridSymbols as a flat array in row-major order (row by row, left to right).
 * The frontend expects a column-major grid: SymbolId[][], where [col][row].
 */
export function convertEngineResultsToGrid(
  engineResults: unknown,
  cols: number = 5,
  rows: number = 3
): SymbolId[][] | null {
  if (!engineResults || typeof engineResults !== 'object') {
    return null;
  }

  // Type guard to check if it has FinalGridSymbols
  // The ResultsEnvelope from the engine has: finalGridSymbols, cascades, wins, rngTransactionId
  // Note: No scatter or free spins in Starburst-style game
  const results = engineResults as {
    finalGridSymbols?: string[] | null;
    cascades?: Array<{
      gridAfter?: string[];
      gridBefore?: string[];
    }>;
  };

  // Try to get final grid symbols
  let symbolCodes: string[] | undefined;
  
  // Check for finalGridSymbols (camelCase from JSON serialization)
  if (results.finalGridSymbols && Array.isArray(results.finalGridSymbols) && results.finalGridSymbols.length > 0) {
    symbolCodes = results.finalGridSymbols;
  } else if (results.cascades && results.cascades.length > 0) {
    // Fallback to last cascade gridAfter
    const lastCascade = results.cascades[results.cascades.length - 1];
    if (lastCascade?.gridAfter && Array.isArray(lastCascade.gridAfter) && lastCascade.gridAfter.length > 0) {
      symbolCodes = lastCascade.gridAfter;
    }
  }
  
  // Debug logging
  if (!symbolCodes) {
    console.warn('No symbol codes found in engine results', {
      hasFinalGridSymbols: !!results.finalGridSymbols,
      finalGridSymbolsLength: results.finalGridSymbols?.length,
      hasCascades: !!results.cascades,
      cascadesLength: results.cascades?.length,
      resultsKeys: Object.keys(results || {})
    });
  }

  if (!symbolCodes || symbolCodes.length !== cols * rows) {
    console.warn('Invalid engine results format or size mismatch', { symbolCodes, cols, rows });
    return null;
  }

  // Convert symbol codes to SymbolId
  // Backend sends codes like 'WILD', 'BAR', etc. which map to frontend SymbolIds
  const symbolMap: Record<string, SymbolId> = {
    'SYM_WILD': 'SYM_WILD',
    'SYM_BAR': 'SYM_BAR',
    'SYM_SEVEN': 'SYM_SEVEN',
    'SYM_RED': 'SYM_RED',
    'SYM_PURPLE': 'SYM_PURPLE',
    'SYM_BLUE': 'SYM_BLUE',
    'SYM_GREEN': 'SYM_GREEN',
    'SYM_ORANGE': 'SYM_ORANGE',
    // Backend symbol codes (without SYM_ prefix)
    'WILD': 'SYM_WILD',
    'BAR': 'SYM_BAR',
    'SEVEN': 'SYM_SEVEN',
    'RED': 'SYM_RED',
    'PURPLE': 'SYM_PURPLE',
    'BLUE': 'SYM_BLUE',
    'GREEN': 'SYM_GREEN',
    'ORANGE': 'SYM_ORANGE',
  };

  // Engine returns symbols in row-major order, bottom-to-top: 
  // [row2col0, row2col1, ..., row2col4, row1col0, row1col1, ..., row0col0, row0col1, ...]
  // Frontend expects column-major: [[col0row0, col0row1, col0row2], [col1row0, ...], ...]
  // Where row0 is top, row2 is bottom
  const grid: SymbolId[][] = [];
  
  for (let col = 0; col < cols; col++) {
    grid[col] = [];
    for (let row = 0; row < rows; row++) {
      // Engine flattens bottom-to-top: row (rows-1) first, then (rows-2), etc.
      // So for a 3-row grid: row2 (index 2) comes first, then row1, then row0
      // Frontend expects top-to-bottom: row0 (top), row1, row2 (bottom)
      // So we need to reverse the row order
      const engineRow = rows - 1 - row; // Convert frontend row (top=0) to engine row (bottom=rows-1)
      const flatIndex = engineRow * cols + col;
      const symbolCode = symbolCodes[flatIndex];
      const symbolId = symbolMap[symbolCode] || 'SYM_BAR'; // Default fallback
      grid[col][row] = symbolId;
    }
  }

  return grid;
}

/**
 * Extracts win information from engine results.
 */
export function extractWinsFromEngineResults(engineResults: unknown): Array<{
  symbolCode: string;
  count: number;
  payout: number;
  indices?: number[];
}> {
  if (!engineResults || typeof engineResults !== 'object') {
    return [];
  }

  const results = engineResults as {
    wins?: Array<{
      symbolCode?: string;
      count?: number;
      multiplier?: number;
      payout?: { amount?: number };
      indices?: number[];
    }>;
  };

  if (!results.wins || !Array.isArray(results.wins)) {
    return [];
  }

  return results.wins
    .filter(win => win.symbolCode && win.count && win.payout)
    .map(win => ({
      symbolCode: win.symbolCode!,
      count: win.count!,
      payout: win.payout?.amount ?? 0,
      indices: win.indices,
    }));
}

